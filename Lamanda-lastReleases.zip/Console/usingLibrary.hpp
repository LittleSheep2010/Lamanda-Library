#ifndef usingLibrary_hpp
#define usingLibrary_hpp

#include <iostream>
#include <fstream>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <iomanip>
using namespace std;

#endif